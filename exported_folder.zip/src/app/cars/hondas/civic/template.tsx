import React from 'react';

const Template = () => {
  return (
    <>
      <div>
        <button></button>
        <p></p>
      </div>
    </>
  );
};

export default Template;
