import React from 'react';

const Route = () => {
  return (
    <>
      <img src=" " />
    </>
  );
};

export default Route;
